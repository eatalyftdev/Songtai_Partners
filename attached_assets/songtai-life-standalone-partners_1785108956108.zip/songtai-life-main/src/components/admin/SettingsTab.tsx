import { useState, FormEvent, ReactElement } from "react";
import {
  MessageCircle, BarChart3, Share2, Globe, Save, Eye, EyeOff,
  ExternalLink, Phone, Mail, MapPin, Image as ImageIcon, Bell
} from "lucide-react";
import { useSiteSettings, saveSiteSetting } from "../../hooks/useSiteSettings";
import WhatsAppWidget from "../WhatsAppWidget";
import MediaUploader from "../MediaUploader";

interface SettingsTabProps {
  addNotification: (msg: string, type: "success" | "info" | "gold") => void;
}

type Tab = "whatsapp" | "order_alerts" | "analytics" | "socials" | "seo" | "contact" | "branding";

const TABS: { id: Tab; label: string; icon: ReactElement }[] = [
  { id: "whatsapp",     label: "WhatsApp",     icon: <MessageCircle className="w-3.5 h-3.5" /> },
  { id: "order_alerts", label: "Order Alerts", icon: <Bell className="w-3.5 h-3.5" /> },
  { id: "analytics",   label: "Analytics",    icon: <BarChart3 className="w-3.5 h-3.5" /> },
  { id: "socials",     label: "Socials",      icon: <Share2 className="w-3.5 h-3.5" /> },
  { id: "seo",         label: "SEO",          icon: <Globe className="w-3.5 h-3.5" /> },
  { id: "contact",     label: "Contact",      icon: <Phone className="w-3.5 h-3.5" /> },
  { id: "branding",    label: "Branding",     icon: <ImageIcon className="w-3.5 h-3.5" /> },
];

export default function SettingsTab({ addNotification }: SettingsTabProps) {
  const settings = useSiteSettings();
  const [activeTab, setActiveTab] = useState<Tab>("whatsapp");

  // ── WhatsApp state ──────────────────────────────────────────────
  const [waEnabled, setWaEnabled]   = useState(settings.whatsapp.enabled);
  const [waNumber, setWaNumber]     = useState(settings.whatsapp.number);
  const [waMessage, setWaMessage]   = useState(settings.whatsapp.default_message);
  const [waLoading, setWaLoading]   = useState(false);
  const [showWaPreview, setShowWaPreview] = useState(false);

  // ── Order Alerts state ──────────────────────────────────────────
  const [oaEnabled, setOaEnabled]   = useState(settings.orderNotifications.enabled);
  const [oaNumber, setOaNumber]     = useState(settings.orderNotifications.whatsapp_number);
  const [oaLoading, setOaLoading]   = useState(false);

  // ── Analytics state ─────────────────────────────────────────────
  const [gaEnabled, setGaEnabled]   = useState(settings.analytics.enabled);
  const [gtmId, setGtmId]           = useState(settings.analytics.gtm_id);
  const [ga4Id, setGa4Id]           = useState(settings.analytics.ga4_id);
  const [gaLoading, setGaLoading]   = useState(false);

  // ── Socials state ───────────────────────────────────────────────
  const [socials, setSocials]       = useState({ ...settings.socials });
  const [socLoading, setSocLoading] = useState(false);

  // ── SEO state ───────────────────────────────────────────────────
  const [seoTitle, setSeoTitle]         = useState(settings.seoDefaults.site_title);
  const [seoDesc, setSeoDesc]           = useState(settings.seoDefaults.meta_description);
  const [seoImg, setSeoImg]             = useState(settings.seoDefaults.og_image_url);
  const [seoKeywords, setSeoKeywords]   = useState(settings.seoDefaults.keywords);
  const [seoGbp, setSeoGbp]             = useState(settings.seoDefaults.google_business_url);
  const [seoAuthor, setSeoAuthor]       = useState(settings.seoDefaults.author);
  const [seoColor, setSeoColor]         = useState(settings.seoDefaults.theme_color);
  const [seoLoading, setSeoLoading]     = useState(false);

  // ── Contact state ───────────────────────────────────────────────
  const [phone, setPhone]           = useState(settings.contact.phone);
  const [email, setEmail]           = useState(settings.contact.email);
  const [addrEn, setAddrEn]         = useState(settings.contact.address_en);
  const [addrFr, setAddrFr]         = useState(settings.contact.address_fr);
  const [mapUrl, setMapUrl]         = useState(settings.contact.map_url);
  const [contactLoading, setContactLoading] = useState(false);

  // ── Branding state ──────────────────────────────────────────────
  const [logoUrl, setLogoUrl]       = useState(settings.branding.logo_url);
  const [logoDarkUrl, setLogoDarkUrl] = useState(settings.branding.logo_dark_url);
  const [faviconUrl, setFaviconUrl] = useState(settings.branding.favicon_url);
  const [brandLoading, setBrandLoading] = useState(false);

  // ── Helpers ─────────────────────────────────────────────────────
  const saveSection = async (key: string, value: object, setLoading: (b: boolean) => void) => {
    setLoading(true);
    const err = await saveSiteSetting(key, value);
    setLoading(false);
    if (err) addNotification("Failed to save: " + err.message, "info");
    else     addNotification("Settings saved.", "success");
  };

  const card = "bg-stone-900 border border-stone-800 rounded-xl p-6 space-y-5";
  const inputCls = "w-full px-3 py-2 bg-stone-950 border border-stone-800 focus:border-[#ecc246] rounded-lg text-sm text-white outline-none";
  const labelCls = "text-stone-400 text-[10px] uppercase font-black block mb-1.5";
  const SaveBtn = ({ loading }: { loading: boolean }) => (
    <button type="submit" disabled={loading}
      className="flex items-center gap-2 px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold rounded-lg cursor-pointer disabled:opacity-60 transition-all min-h-[36px]">
      {loading
        ? <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
        : <Save className="w-3.5 h-3.5" />}
      Save
    </button>
  );

  const SOCIAL_FIELDS: { key: keyof typeof socials; label: string; placeholder: string }[] = [
    { key: "facebook",  label: "Facebook URL",  placeholder: "https://facebook.com/songtailife" },
    { key: "instagram", label: "Instagram URL", placeholder: "https://instagram.com/songtailife" },
    { key: "tiktok",    label: "TikTok URL",    placeholder: "https://tiktok.com/@songtailife" },
    { key: "youtube",   label: "YouTube URL",   placeholder: "https://youtube.com/@songtailife" },
    { key: "linkedin",  label: "LinkedIn URL",  placeholder: "https://linkedin.com/company/songtailife" },
    { key: "whatsapp",  label: "WhatsApp URL",  placeholder: "https://wa.me/237655000000" },
  ];

  return (
    <div className="space-y-6 text-left animate-fade-in">
      <div>
        <h3 className="font-extrabold text-lg text-stone-100">Site Settings</h3>
        <p className="text-xs text-stone-500">Changes take effect site-wide in real time — no redeploy needed.</p>
      </div>

      {/* Tab pills */}
      <div className="flex flex-wrap gap-1.5 p-1 bg-stone-950 rounded-xl border border-stone-800">
        {TABS.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer min-h-[36px] ${
              activeTab === tab.id
                ? "bg-stone-800 text-white"
                : "text-stone-500 hover:text-stone-300"
            }`}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}
      </div>

      {/* ── WhatsApp ───────────────────────────────────────────────── */}
      {activeTab === "whatsapp" && (
        <form onSubmit={e => { e.preventDefault(); saveSection("whatsapp", { enabled: waEnabled, number: waNumber, default_message: waMessage }, setWaLoading); }} className={card}>
          <div className="flex items-center gap-2 pb-3 border-b border-stone-800">
            <MessageCircle className="w-4 h-4 text-green-400" />
            <h4 className="font-bold text-sm text-stone-100">WhatsApp Floating Button</h4>
          </div>
          <p className="text-[11px] text-stone-500">Customer support widget shown to visitors on the public site. Configure a separate number for order alerts in the <strong>Order Alerts</strong> tab.</p>
          <label className="flex items-center gap-3 cursor-pointer">
            <div className={`w-10 h-5 rounded-full relative transition-colors ${waEnabled ? "bg-green-500" : "bg-stone-700"}`}
              onClick={() => setWaEnabled(v => !v)}>
              <span className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all ${waEnabled ? "left-5" : "left-0.5"}`} />
            </div>
            <span className="text-sm text-stone-300">{waEnabled ? "Enabled — visible to visitors" : "Disabled — hidden from visitors"}</span>
          </label>
          <div>
            <label className={labelCls}>Phone Number (E.164)</label>
            <input type="text" value={waNumber} onChange={e => setWaNumber(e.target.value)} placeholder="+237655000000" className={inputCls} />
            <p className="text-[10px] text-stone-600 mt-1">Include country code. No spaces or dashes.</p>
          </div>
          <div>
            <label className={labelCls}>Default Message</label>
            <textarea rows={2} value={waMessage} onChange={e => setWaMessage(e.target.value)} className={`${inputCls} resize-none`} />
          </div>
          <div>
            <button type="button" onClick={() => setShowWaPreview(v => !v)}
              className="flex items-center gap-1.5 text-[11px] text-[#ecc246] hover:text-[#dbb13b] font-bold cursor-pointer">
              {showWaPreview ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
              {showWaPreview ? "Hide preview" : "Show button preview"}
            </button>
            {showWaPreview && (
              <div className="mt-3 p-4 bg-stone-950/60 border border-stone-800 rounded-xl relative h-24 flex items-end justify-end">
                <span className="text-[10px] text-stone-600 absolute top-3 left-3">Preview</span>
                <div className="flex items-center justify-center w-14 h-14 rounded-full shadow-xl cursor-default" style={{ background: "#25D366" }}>
                  <svg viewBox="0 0 24 24" className="w-7 h-7 fill-white"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.886 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                </div>
              </div>
            )}
          </div>
          <div className="flex justify-end"><SaveBtn loading={waLoading} /></div>
        </form>
      )}

      {/* ── Order Alerts ───────────────────────────────────────────── */}
      {activeTab === "order_alerts" && (
        <form onSubmit={e => { e.preventDefault(); saveSection("order_notifications", { enabled: oaEnabled, whatsapp_number: oaNumber }, setOaLoading); }} className={card}>
          <div className="flex items-center gap-2 pb-3 border-b border-stone-800">
            <Bell className="w-4 h-4 text-[#ecc246]" />
            <h4 className="font-bold text-sm text-stone-100">Order Alerts — WhatsApp Notifications</h4>
          </div>
          <p className="text-[11px] text-stone-500">
            When enabled, the admin receives an instant WhatsApp message the moment a customer completes payment. This uses the Twilio Business API — configure <code className="text-[#ecc246]">TWILIO_ACCOUNT_SID</code>, <code className="text-[#ecc246]">TWILIO_AUTH_TOKEN</code>, and <code className="text-[#ecc246]">TWILIO_WHATSAPP_FROM</code> as environment secrets on the server.
          </p>
          <label className="flex items-center gap-3 cursor-pointer">
            <div className={`w-10 h-5 rounded-full relative transition-colors ${oaEnabled ? "bg-[#ecc246]" : "bg-stone-700"}`}
              onClick={() => setOaEnabled(v => !v)}>
              <span className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all ${oaEnabled ? "left-5" : "left-0.5"}`} />
            </div>
            <span className="text-sm text-stone-300">{oaEnabled ? "Order alerts enabled" : "Order alerts disabled"}</span>
          </label>
          <div>
            <label className={labelCls}>Admin WhatsApp Number (E.164) *</label>
            <input
              type="text"
              value={oaNumber}
              onChange={e => setOaNumber(e.target.value)}
              placeholder="+237655000000"
              className={inputCls}
            />
            <p className="text-[10px] text-stone-600 mt-1">
              This is separate from the public customer support widget number. Order summaries will be sent here.
            </p>
          </div>
          <div className="p-3 bg-stone-950/60 border border-stone-800/60 rounded-xl text-[11px] text-stone-500 space-y-1">
            <p className="font-semibold text-stone-400">Message includes:</p>
            <ul className="list-disc list-inside space-y-0.5 ml-1">
              <li>Order ID and payment amount</li>
              <li>Customer name, phone, and delivery address</li>
              <li>Delivery notes (if provided)</li>
              <li>Ordered products list</li>
            </ul>
          </div>
          <div className="flex justify-end"><SaveBtn loading={oaLoading} /></div>
        </form>
      )}

      {/* ── Analytics ──────────────────────────────────────────────── */}
      {activeTab === "analytics" && (
        <form onSubmit={e => { e.preventDefault(); saveSection("analytics", { enabled: gaEnabled, gtm_id: gtmId, ga4_id: ga4Id }, setGaLoading); }} className={card}>
          <div className="flex items-center gap-2 pb-3 border-b border-stone-800">
            <BarChart3 className="w-4 h-4 text-blue-400" />
            <h4 className="font-bold text-sm text-stone-100">Google Tag Manager / GA4</h4>
          </div>
          <label className="flex items-center gap-3 cursor-pointer">
            <div className={`w-10 h-5 rounded-full relative transition-colors ${gaEnabled ? "bg-emerald-600" : "bg-stone-700"}`}
              onClick={() => setGaEnabled(v => !v)}>
              <span className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all ${gaEnabled ? "left-5" : "left-0.5"}`} />
            </div>
            <span className="text-sm text-stone-300">{gaEnabled ? "Analytics enabled" : "Analytics disabled"}</span>
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className={labelCls}>GTM Container ID</label>
              <input type="text" value={gtmId} onChange={e => setGtmId(e.target.value)} placeholder="GTM-XXXXXXX" className={inputCls} />
              <p className="text-[10px] text-stone-600 mt-1">Preferred — GTM can manage GA4 internally.</p>
            </div>
            <div>
              <label className={labelCls}>GA4 Measurement ID</label>
              <input type="text" value={ga4Id} onChange={e => setGa4Id(e.target.value)} placeholder="G-XXXXXXXXXX" className={inputCls} />
              <p className="text-[10px] text-stone-600 mt-1">Used only if GTM ID is empty.</p>
            </div>
          </div>
          <div className="flex justify-end"><SaveBtn loading={gaLoading} /></div>
        </form>
      )}

      {/* ── Socials ────────────────────────────────────────────────── */}
      {activeTab === "socials" && (
        <form onSubmit={e => { e.preventDefault(); saveSection("socials", socials, setSocLoading); }} className={card}>
          <div className="flex items-center gap-2 pb-3 border-b border-stone-800">
            <Share2 className="w-4 h-4 text-pink-400" />
            <h4 className="font-bold text-sm text-stone-100">Social Links</h4>
          </div>
          <p className="text-[11px] text-stone-500">Leave a field blank to hide that platform's icon from the footer.</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {SOCIAL_FIELDS.map(f => (
              <div key={f.key}>
                <label className={labelCls}>{f.label}</label>
                <div className="relative">
                  <ExternalLink className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-stone-600" />
                  <input type="url" value={socials[f.key]}
                    onChange={e => setSocials(s => ({ ...s, [f.key]: e.target.value }))}
                    placeholder={f.placeholder} className={`${inputCls} pl-8`} />
                </div>
              </div>
            ))}
          </div>
          <div className="flex justify-end"><SaveBtn loading={socLoading} /></div>
        </form>
      )}

      {/* ── SEO Defaults ───────────────────────────────────────────── */}
      {activeTab === "seo" && (
        <form onSubmit={e => {
          e.preventDefault();
          saveSection("seo_defaults", {
            site_title: seoTitle,
            meta_description: seoDesc,
            og_image_url: seoImg,
            keywords: seoKeywords,
            google_business_url: seoGbp,
            author: seoAuthor,
            theme_color: seoColor,
          }, setSeoLoading);
        }} className={card}>
          <div className="flex items-center gap-2 pb-3 border-b border-stone-800">
            <Globe className="w-4 h-4 text-[#ecc246]" />
            <h4 className="font-bold text-sm text-stone-100">SEO &amp; Discoverability</h4>
          </div>
          <p className="text-[11px] text-stone-500">All fields propagate to every page in real time — no redeploy needed. Affects Google ranking, social sharing, and Google Business Profile linking.</p>

          {/* Row 1: title + author */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className={labelCls}>Site Title</label>
              <input type="text" value={seoTitle} onChange={e => setSeoTitle(e.target.value)} placeholder="Songtai Life" className={inputCls} />
            </div>
            <div>
              <label className={labelCls}>Author / Publisher Name</label>
              <input type="text" value={seoAuthor} onChange={e => setSeoAuthor(e.target.value)} placeholder="Songtai Life" className={inputCls} />
            </div>
          </div>

          {/* Meta description */}
          <div>
            <label className={labelCls}>Default Meta Description <span className="normal-case text-stone-600">(aim for 150–160 chars)</span></label>
            <textarea rows={3} value={seoDesc} onChange={e => setSeoDesc(e.target.value)} className={`${inputCls} resize-none`} />
            <p className={`text-right text-[10px] mt-1 ${seoDesc.length > 160 ? "text-red-400" : "text-stone-600"}`}>{seoDesc.length} / 160</p>
          </div>

          {/* Keywords */}
          <div>
            <label className={labelCls}>Keywords <span className="normal-case text-stone-600">(comma-separated, 5–15 terms)</span></label>
            <textarea rows={2} value={seoKeywords} onChange={e => setSeoKeywords(e.target.value)}
              placeholder="Songtai Life, MLM Cameroon, natural products, wellness Cameroon, …"
              className={`${inputCls} resize-none`} />
          </div>

          {/* Row 2: Google Business Profile + theme color */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className={labelCls}>Google Business Profile URL</label>
              <input type="url" value={seoGbp} onChange={e => setSeoGbp(e.target.value)}
                placeholder="https://maps.app.goo.gl/…"
                className={inputCls} />
              <p className="text-[10px] text-stone-600 mt-1">Links your site to your Google Business listing in structured data — boosts local search.</p>
            </div>
            <div>
              <label className={labelCls}>Brand Theme Color</label>
              <div className="flex items-center gap-2">
                <input type="color" value={seoColor} onChange={e => setSeoColor(e.target.value)}
                  className="w-10 h-9 rounded cursor-pointer bg-transparent border-0 p-0.5" />
                <input type="text" value={seoColor} onChange={e => setSeoColor(e.target.value)}
                  placeholder="#0A7D32" className={`${inputCls} flex-1 font-mono`} />
              </div>
              <p className="text-[10px] text-stone-600 mt-1">Used for browser tab color on mobile Chrome / Safari.</p>
            </div>
          </div>

          {/* OG Image */}
          <div>
            <label className={labelCls}>Default OG / Social Share Image <span className="normal-case text-stone-600">(1200×630px recommended)</span></label>
            <MediaUploader
              bucket="media"
              folder="branding"
              currentUrl={seoImg || undefined}
              onUploaded={url => setSeoImg(url)}
              onRemoved={() => setSeoImg("")}
              maxSizeMb={3}
              label="Drop OG image here or click to browse"
            />
          </div>

          <div className="flex justify-end"><SaveBtn loading={seoLoading} /></div>
        </form>
      )}

      {/* ── Contact ────────────────────────────────────────────────── */}
      {activeTab === "contact" && (
        <form onSubmit={e => { e.preventDefault(); saveSection("contact", { phone, email, address_en: addrEn, address_fr: addrFr, map_url: mapUrl }, setContactLoading); }} className={card}>
          <div className="flex items-center gap-2 pb-3 border-b border-stone-800">
            <Phone className="w-4 h-4 text-emerald-400" />
            <h4 className="font-bold text-sm text-stone-100">Contact & Location</h4>
          </div>
          <p className="text-[11px] text-stone-500">These appear in the footer and on the Contact page. Leave blank to hide.</p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className={labelCls}>
                <span className="flex items-center gap-1"><Phone className="w-3 h-3" /> Phone Number</span>
              </label>
              <input type="text" value={phone} onChange={e => setPhone(e.target.value)} placeholder="+237 6xx xxx xxx" className={inputCls} />
            </div>
            <div>
              <label className={labelCls}>
                <span className="flex items-center gap-1"><Mail className="w-3 h-3" /> Email Address</span>
              </label>
              <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="support@songtailife.com" className={inputCls} />
            </div>
          </div>
          <div>
            <label className={labelCls}>
              <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> Address (English)</span>
            </label>
            <textarea rows={2} value={addrEn} onChange={e => setAddrEn(e.target.value)}
              placeholder="Yaoundé: Avenue Kennedy&#10;Douala: Akwa District" className={`${inputCls} resize-none`} />
          </div>
          <div>
            <label className={labelCls}>
              <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> Address (French)</span>
            </label>
            <textarea rows={2} value={addrFr} onChange={e => setAddrFr(e.target.value)}
              placeholder="Yaoundé : Avenue Kennedy&#10;Douala : Quartier Akwa" className={`${inputCls} resize-none`} />
          </div>
          <div>
            <label className={labelCls}>Google Maps Embed URL (optional)</label>
            <input type="url" value={mapUrl} onChange={e => setMapUrl(e.target.value)} placeholder="https://maps.google.com/..." className={inputCls} />
          </div>
          <div className="flex justify-end"><SaveBtn loading={contactLoading} /></div>
        </form>
      )}

      {/* ── Branding ───────────────────────────────────────────────── */}
      {activeTab === "branding" && (
        <form onSubmit={e => { e.preventDefault(); saveSection("branding", { logo_url: logoUrl, logo_dark_url: logoDarkUrl, favicon_url: faviconUrl }, setBrandLoading); }} className={card}>
          <div className="flex items-center gap-2 pb-3 border-b border-stone-800">
            <ImageIcon className="w-4 h-4 text-[#C9A227]" />
            <h4 className="font-bold text-sm text-stone-100">Brand Assets</h4>
          </div>
          <p className="text-[11px] text-stone-500">
            Upload directly — assets are hosted in Supabase Storage and propagate everywhere instantly.
          </p>

          <div>
            <label className={labelCls}>Primary Logo (light backgrounds)</label>
            <MediaUploader
              bucket="media"
              folder="branding"
              currentUrl={logoUrl || undefined}
              onUploaded={url => setLogoUrl(url)}
              onRemoved={() => setLogoUrl("")}
              maxSizeMb={2}
              label="Drop primary logo here or click to browse (PNG/SVG recommended)"
            />
          </div>

          <div>
            <label className={labelCls}>Dark Mode Logo (dark backgrounds)</label>
            <p className="text-[10px] text-stone-600 mb-2">If not uploaded, a CSS filter is applied to the primary logo instead.</p>
            <MediaUploader
              bucket="media"
              folder="branding"
              currentUrl={logoDarkUrl || undefined}
              onUploaded={url => setLogoDarkUrl(url)}
              onRemoved={() => setLogoDarkUrl("")}
              maxSizeMb={2}
              label="Drop dark-mode logo here or click to browse"
            />
          </div>

          <div>
            <label className={labelCls}>Favicon</label>
            <MediaUploader
              bucket="media"
              folder="branding"
              accept="image/png,image/x-icon,image/svg+xml"
              currentUrl={faviconUrl || undefined}
              onUploaded={url => setFaviconUrl(url)}
              onRemoved={() => setFaviconUrl("")}
              maxSizeMb={1}
              label="Drop favicon here (PNG 32×32, ICO, or SVG)"
            />
          </div>

          <div className="flex justify-end"><SaveBtn loading={brandLoading} /></div>
        </form>
      )}
    </div>
  );
}
