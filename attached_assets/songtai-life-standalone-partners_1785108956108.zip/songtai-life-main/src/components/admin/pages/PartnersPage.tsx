import { useState, useEffect, FormEvent, ReactNode } from "react";
import {
  Globe, Plus, Edit2, CheckCircle, PauseCircle, PlayCircle,
  Link2, Copy, Check, ExternalLink, AlertTriangle, User,
  RefreshCw, Shield, XCircle
} from "lucide-react";
import { useAuth } from "../../../context/AuthContext";
import PageShell, { Card, TableWrapper, Th, Td, Btn, SearchInput, Select } from "../shared/PageShell";
import SlideOver from "../shared/SlideOver";
import { SkeletonTable } from "../shared/Skeleton";
import EmptyState from "../shared/EmptyState";
import MediaUploader from "../../MediaUploader";

// ── Types ────────────────────────────────────────────────────────────────────
interface Partner {
  id: string;
  slug: string;
  status: "pending" | "active" | "suspended";
  display_name: string | null;
  whatsapp_number: string | null;
  contact_email: string | null;
  hero_title_en: string | null;
  hero_title_fr: string | null;
  hero_subtitle_en: string | null;
  hero_subtitle_fr: string | null;
  hero_image_url: string | null;
  distributor_id: string | null;
  pending_contact_name: string | null;
  pending_contact_phone: string | null;
  custom_domain: string | null;
  domain_status: "none" | "pending_verification" | "verified" | "failed" | null;
  domain_verification_token: string | null;
  domain_check_attempts: number | null;
  domain_last_checked_at: string | null;
  vercel_domain_added_at: string | null;
  deployment_mode: "shared_path" | "standalone";
  standalone_url: string | null;
  setup_completed_at: string | null;
  created_at: string;
  approved_at: string | null;
  distributorEmail?: string;
  distributorCode?: string;
}

interface FormState {
  slug: string;
  deploymentMode: "shared_path" | "standalone";
  pendingContactName: string;
  pendingContactPhone: string;
  displayName: string;
  whatsappNumber: string;
  contactEmail: string;
  heroTitleEn: string;
  heroTitleFr: string;
  heroSubtitleEn: string;
  heroSubtitleFr: string;
  heroImageUrl: string;
  distributorId: string;
  status: "pending" | "active" | "suspended";
  customDomain: string;
}

const BLANK: FormState = {
  slug: "", deploymentMode: "shared_path", pendingContactName: "", pendingContactPhone: "", displayName: "",
  whatsappNumber: "", contactEmail: "",
  heroTitleEn: "", heroTitleFr: "", heroSubtitleEn: "", heroSubtitleFr: "",
  heroImageUrl: "", distributorId: "", status: "active", customDomain: "",
};

// ── Status chip ──────────────────────────────────────────────────────────────
function StatusChip({ status }: { status: Partner["status"] }) {
  const map: Record<Partner["status"], { label: string; cls: string; icon: ReactNode }> = {
    active:    { label: "Active",    cls: "bg-emerald-900/40 text-emerald-400 border-emerald-800/40", icon: <CheckCircle className="w-3 h-3" /> },
    pending:   { label: "Pending",   cls: "bg-amber-900/40 text-amber-400 border-amber-800/40",      icon: <PauseCircle className="w-3 h-3" /> },
    suspended: { label: "Suspended", cls: "bg-red-900/30 text-red-400 border-red-800/30",            icon: <PauseCircle className="w-3 h-3" /> },
  };
  const { label, cls, icon } = map[status] ?? map.pending;
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold border ${cls}`}>
      {icon}{label}
    </span>
  );
}

// ── Form field helpers ───────────────────────────────────────────────────────
function Label({ children }: { children: ReactNode }) {
  return <label className="block text-xs font-semibold text-stone-400 mb-1">{children}</label>;
}
function Input({ value, onChange, placeholder = "", disabled = false, mono = false }: {
  value: string; onChange: (v: string) => void; placeholder?: string; disabled?: boolean; mono?: boolean;
}) {
  return (
    <input
      value={value}
      onChange={e => onChange(e.target.value)}
      placeholder={placeholder}
      disabled={disabled}
      className={`w-full bg-stone-900 border border-stone-700 rounded-xl px-3 py-2.5 text-sm text-white placeholder-stone-600 focus:outline-none focus:border-emerald-600 transition-colors disabled:opacity-50 ${mono ? "font-mono" : ""}`}
    />
  );
}
function FormRow({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div>
      <Label>{label}</Label>
      {children}
    </div>
  );
}
function SectionHeader({ children }: { children: ReactNode }) {
  return (
    <div className="flex items-center gap-2 pt-2 pb-1 border-b border-stone-800">
      <span className="text-[10px] font-bold uppercase tracking-widest text-stone-500">{children}</span>
    </div>
  );
}

// ── Main component ───────────────────────────────────────────────────────────
export default function PartnersPage() {
  const { session } = useAuth();
  const [partners, setPartners] = useState<Partner[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [slideOpen, setSlideOpen] = useState(false);
  const [editing, setEditing] = useState<Partner | null>(null);
  const [form, setForm] = useState<FormState>(BLANK);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [createdPartner, setCreatedPartner] = useState<Partner | null>(null);
  const [copiedSlug, setCopiedSlug] = useState("");
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [domainOp, setDomainOp] = useState<"attaching" | "checking" | "removing" | null>(null);
  const [dnsRecords, setDnsRecords] = useState<{ type: string; domain: string; value: string }[]>([]);
  const [domainOpMsg, setDomainOpMsg] = useState("");
  const [savedMsg, setSavedMsg] = useState("");
  const [showSlugWarning, setShowSlugWarning] = useState(false);

  // ── Load partners ──────────────────────────────────────────────────────────
  const load = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/partners", {
        headers: { Authorization: `Bearer ${session?.access_token}` },
      });
      if (res.ok) setPartners(await res.json());
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  // ── Filter ─────────────────────────────────────────────────────────────────
  const filtered = partners.filter(p => {
    if (statusFilter !== "all" && p.status !== statusFilter) return false;
    const q = search.toLowerCase();
    return !q
      || p.slug.includes(q)
      || (p.pending_contact_name ?? "").toLowerCase().includes(q)
      || (p.pending_contact_phone ?? "").includes(q)
      || (p.whatsapp_number ?? "").includes(q);
  });

  // ── Open create / edit slide-over ──────────────────────────────────────────
  const openCreate = () => {
    setEditing(null);
    setCreatedPartner(null);
    setForm(BLANK);
    setError("");
    setSlideOpen(true);
  };

  const openEdit = (p: Partner) => {
    setCreatedPartner(null);
    setDnsRecords([]);
    setDomainOpMsg("");
    setSavedMsg("");
    setShowSlugWarning(false);
    setEditing(p);
    setForm({
      slug: p.slug,
      deploymentMode: p.deployment_mode ?? "shared_path",
      pendingContactName: p.pending_contact_name ?? "",
      pendingContactPhone: p.pending_contact_phone ?? "",
      displayName: p.display_name ?? "",
      whatsappNumber: p.whatsapp_number ?? "",
      contactEmail: p.contact_email ?? "",
      heroTitleEn: p.hero_title_en ?? "",
      heroTitleFr: p.hero_title_fr ?? "",
      heroSubtitleEn: p.hero_subtitle_en ?? "",
      heroSubtitleFr: p.hero_subtitle_fr ?? "",
      heroImageUrl: p.hero_image_url ?? "",
      distributorId: p.distributor_id ?? "",
      status: p.status === "suspended" ? "pending" : p.status,
      customDomain: p.custom_domain ?? "",
    });
    setError("");
    setSlideOpen(true);
  };

  // ── Save (create or update) ────────────────────────────────────────────────
  const handleSave = async (e: FormEvent) => {
    e.preventDefault();
    setError("");

    if (!editing && !/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(form.slug)) {
      setError("Slug must be lowercase letters, numbers, and hyphens only (e.g. jane-doe).");
      return;
    }

    setSaving(true);
    try {
      const payload: Record<string, any> = {
        slug:               form.slug,
        ...(editing ? {} : { deploymentMode: form.deploymentMode }),
        pendingContactName: form.pendingContactName  || null,
        pendingContactPhone:form.pendingContactPhone || null,
        displayName:        form.displayName         || null,
        whatsappNumber:     form.whatsappNumber      || null,
        contactEmail:       form.contactEmail        || null,
        heroTitleEn:        form.heroTitleEn         || null,
        heroTitleFr:        form.heroTitleFr         || null,
        heroSubtitleEn:     form.heroSubtitleEn      || null,
        heroSubtitleFr:     form.heroSubtitleFr      || null,
        heroImageUrl:       form.heroImageUrl        || null,
        distributorId:      form.distributorId       || null,
        status:             form.status,
        // customDomain is only sent on edit — the create endpoint ignores it;
        // custom domain setup is an explicit post-creation step via /domain/attach
        ...(editing ? { customDomain: form.customDomain || null } : {}),
      };

      const url = editing
        ? `/api/admin/partner/${editing.id}`
        : "/api/admin/partner/create";
      const method = editing ? "PUT" : "POST";

      const res = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${session?.access_token}`,
        },
        body: JSON.stringify(payload),
      });

      // Safe JSON parse — the server might return HTML on unhandled errors
      const contentType = res.headers.get("content-type") ?? "";
      let json: any = {};
      if (contentType.includes("application/json")) {
        json = await res.json();
      } else {
        const raw = await res.text();
        console.error("[PartnersPage] Non-JSON response:", res.status, raw.slice(0, 300));
        setError(`Server error (${res.status}). Check console for details.`);
        return;
      }

      if (!res.ok) {
        setError(json.error ?? "Failed to save partner.");
        return;
      }

      load();
      if (!editing && json.partner) {
        // Show success panel with the live URL instead of just closing
        setCreatedPartner(json.partner as Partner);
      } else if (editing && json.partner) {
        // Keep slide open — refresh editing state so domain section reflects saved values
        const updated = json.partner as Partner;
        setEditing(updated);
        setForm(f => ({ ...f, slug: updated.slug }));
        setSavedMsg("Changes saved.");
        setTimeout(() => setSavedMsg(""), 3000);
        load();
      } else {
        setSlideOpen(false);
      }
    } catch (err: any) {
      setError(err.message ?? "Unexpected error.");
    } finally {
      setSaving(false);
    }
  };

  // ── Status actions ─────────────────────────────────────────────────────────
  const setStatus = async (id: string, newStatus: "active" | "suspended" | "pending") => {
    setActionLoading(id);
    try {
      await fetch(`/api/admin/partner/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${session?.access_token}`,
        },
        body: JSON.stringify({ status: newStatus }),
      });
      setPartners(prev => prev.map(p => p.id === id ? { ...p, status: newStatus } : p));
    } finally {
      setActionLoading(null);
    }
  };

  // ── Copy slug URL ──────────────────────────────────────────────────────────
  const copyUrl = (slug: string) => {
    const url = `${window.location.origin}/p/${slug}`;
    navigator.clipboard.writeText(url);
    setCopiedSlug(slug);
    setTimeout(() => setCopiedSlug(""), 2000);
  };

  const relTime = (iso: string) => {
    const d = Math.floor((Date.now() - new Date(iso).getTime()) / 86400000);
    return d === 0 ? "Today" : `${d}d ago`;
  };

  // ── Domain management ──────────────────────────────────────────────────────
  const attachDomain = async (id: string, domain: string) => {
    setDomainOp("attaching");
    setDnsRecords([]);
    setDomainOpMsg("");
    try {
      const res = await fetch(`/api/admin/partner/${id}/domain/attach`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
        body: JSON.stringify({ domain }),
      });
      const json = await res.json();
      if (!res.ok) { setDomainOpMsg(json.error ?? "Failed to attach domain."); return; }
      setDnsRecords(json.verification ?? []);
      setDomainOpMsg(json.message ?? "Domain attached.");
      setPartners(prev => prev.map(p => p.id === id ? { ...p, custom_domain: domain, domain_status: "pending_verification" } : p));
      if (editing?.id === id) setEditing(e => e ? { ...e, custom_domain: domain, domain_status: "pending_verification" } : e);
    } catch (err: any) {
      setDomainOpMsg(err.message ?? "Unexpected error.");
    } finally {
      setDomainOp(null);
    }
  };

  const checkDomainStatus = async (id: string) => {
    setDomainOp("checking");
    setDomainOpMsg("");
    try {
      const res = await fetch(`/api/admin/partner/${id}/domain/check`, {
        method: "POST",
        headers: { Authorization: `Bearer ${session?.access_token}` },
      });
      const json = await res.json();
      if (!res.ok) { setDomainOpMsg(json.error ?? "Failed to check domain."); return; }
      setDnsRecords(json.verification ?? []);
      setDomainOpMsg(json.message ?? "");
      const newStatus = json.domain_status as Partner["domain_status"];
      setPartners(prev => prev.map(p => p.id === id ? { ...p, domain_status: newStatus } : p));
      if (editing?.id === id) setEditing(e => e ? { ...e, domain_status: newStatus } : e);
    } catch (err: any) {
      setDomainOpMsg(err.message ?? "Unexpected error.");
    } finally {
      setDomainOp(null);
    }
  };

  const removeDomain = async (id: string) => {
    setDomainOp("removing");
    setDomainOpMsg("");
    try {
      const res = await fetch(`/api/admin/partner/${id}/domain`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${session?.access_token}` },
      });
      const json = await res.json();
      if (!res.ok) { setDomainOpMsg(json.error ?? "Failed to remove domain."); return; }
      setDnsRecords([]);
      setDomainOpMsg(json.message ?? "Domain removed.");
      setPartners(prev => prev.map(p => p.id === id ? { ...p, custom_domain: null, domain_status: "none" } : p));
      if (editing?.id === id) {
        setEditing(e => e ? { ...e, custom_domain: null, domain_status: "none" } : e);
        setForm(f => ({ ...f, customDomain: "" }));
      }
    } catch (err: any) {
      setDomainOpMsg(err.message ?? "Unexpected error.");
    } finally {
      setDomainOp(null);
    }
  };

  return (
    <PageShell
      title="Partner Sites"
      subtitle={`${partners.length} total · ${partners.filter(p => p.status === "active").length} active`}
      actions={
        <Btn variant="primary" onClick={openCreate}>
          <Plus className="w-3.5 h-3.5" /> New Partner Site
        </Btn>
      }
    >
      {/* ── RLS reminder banner ── */}
      <div className="flex items-start gap-3 px-4 py-3 bg-amber-950/30 border border-amber-800/40 rounded-2xl text-xs text-amber-300">
        <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" />
        <span>
          <strong>RLS required:</strong> The <code className="font-mono bg-stone-900 px-1 rounded">partners</code> table must have a Supabase Row Level Security policy allowing anon reads of <code className="font-mono bg-stone-900 px-1 rounded">status = 'active'</code> rows. Without it, partner sites will show "not available" for all visitors.
        </span>
      </div>

      <Card>
        <div className="flex flex-wrap gap-3 p-4 border-b border-stone-800">
          <SearchInput value={search} onChange={setSearch} placeholder="Slug, contact name, phone…" />
          <Select value={statusFilter} onChange={setStatusFilter}>
            <option value="all">All statuses</option>
            <option value="active">Active</option>
            <option value="pending">Pending</option>
            <option value="suspended">Suspended</option>
          </Select>
        </div>

        <TableWrapper>
          <thead>
            <tr>
              <Th>Partner / Contact</Th>
              <Th>Slug / URL</Th>
              <Th>WhatsApp</Th>
              <Th>Status</Th>
              <Th>Created</Th>
              <Th className="text-right">Actions</Th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <SkeletonTable cols={6} />
            ) : filtered.length === 0 ? (
              <tr>
                <td colSpan={6}>
                  <EmptyState icon={Globe} title="No partner sites yet" description="Create the first partner site using the button above." />
                </td>
              </tr>
            ) : filtered.map(p => (
              <tr key={p.id} className="hover:bg-stone-800/30 transition-colors">
                <Td>
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full bg-emerald-900/40 border border-emerald-800/40 flex items-center justify-center flex-shrink-0">
                      <User className="w-3.5 h-3.5 text-emerald-400" />
                    </div>
                    <div>
                      <p className="font-semibold text-white text-xs">
                        {p.pending_contact_name ?? p.slug}
                      </p>
                      {p.pending_contact_phone && (
                        <p className="text-stone-500 text-[10px]">{p.pending_contact_phone}</p>
                      )}
                      {!p.distributor_id && (
                        <span className="text-[10px] text-amber-500 font-medium">No distributor linked</span>
                      )}
                    </div>
                  </div>
                </Td>
                <Td>
                  {p.deployment_mode === "standalone" ? (
                    <div className="flex flex-col gap-1">
                      <span className="inline-flex items-center gap-1 w-fit text-[9px] font-bold uppercase px-1.5 py-0.5 rounded bg-violet-900/40 text-violet-300 border border-violet-800/40">
                        <Globe className="w-2.5 h-2.5" /> Standalone
                      </span>
                      {p.standalone_url ? (
                        <div className="flex items-center gap-1.5">
                          <a
                            href={p.standalone_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="font-mono text-stone-400 text-[11px] hover:text-stone-200 truncate max-w-[160px]"
                            title={p.standalone_url}
                          >
                            {p.standalone_url.replace(/^https?:\/\//, "")}
                          </a>
                          <a
                            href={p.standalone_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-1 rounded hover:bg-stone-800 text-stone-500 hover:text-stone-300 transition-colors flex-shrink-0"
                            title="Open partner site"
                          >
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        </div>
                      ) : (
                        <span className="text-[10px] text-amber-500 font-medium">
                          {p.setup_completed_at ? "Deployment URL not recorded" : "Awaiting self-setup"}
                        </span>
                      )}
                    </div>
                  ) : (
                    <>
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono text-stone-400 text-[11px]">/p/{p.slug}</span>
                        <button
                          onClick={() => copyUrl(p.slug)}
                          className="p-1 rounded hover:bg-stone-800 text-stone-500 hover:text-stone-300 transition-colors cursor-pointer"
                          title="Copy partner URL"
                        >
                          {copiedSlug === p.slug ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                        </button>
                        <a
                          href={`/p/${p.slug}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-1 rounded hover:bg-stone-800 text-stone-500 hover:text-stone-300 transition-colors"
                          title="Open partner site"
                        >
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                      {p.custom_domain && (
                        <div className="flex items-center gap-1 mt-0.5">
                          <Link2 className="w-2.5 h-2.5 text-stone-600" />
                          <span className="text-[10px] text-stone-500 font-mono">{p.custom_domain}</span>
                          <span className={`text-[9px] font-bold uppercase px-1 rounded ${
                            p.domain_status === "verified" ? "bg-emerald-900/40 text-emerald-400" :
                            p.domain_status === "failed"   ? "bg-red-900/30 text-red-400" :
                            "bg-amber-900/30 text-amber-400"
                          }`}>
                            {p.domain_status ?? "none"}
                          </span>
                        </div>
                      )}
                    </>
                  )}
                </Td>
                <Td>{p.whatsapp_number ?? <span className="text-stone-600">—</span>}</Td>
                <Td><StatusChip status={p.status} /></Td>
                <Td>{relTime(p.created_at)}</Td>
                <Td className="text-right">
                  <div className="flex items-center justify-end gap-1.5">
                    <Btn variant="secondary" size="xs" onClick={() => openEdit(p)}>
                      <Edit2 className="w-3 h-3" /> Edit
                    </Btn>
                    {p.status === "pending" && (
                      <Btn
                        variant="primary" size="xs"
                        loading={actionLoading === p.id}
                        onClick={() => setStatus(p.id, "active")}
                      >
                        <CheckCircle className="w-3 h-3" /> Approve
                      </Btn>
                    )}
                    {p.status === "active" && (
                      <Btn
                        variant="danger" size="xs"
                        loading={actionLoading === p.id}
                        onClick={() => setStatus(p.id, "suspended")}
                      >
                        <PauseCircle className="w-3 h-3" /> Suspend
                      </Btn>
                    )}
                    {p.status === "suspended" && (
                      <Btn
                        variant="secondary" size="xs"
                        loading={actionLoading === p.id}
                        onClick={() => setStatus(p.id, "active")}
                      >
                        <PlayCircle className="w-3 h-3" /> Reactivate
                      </Btn>
                    )}
                  </div>
                </Td>
              </tr>
            ))}
          </tbody>
        </TableWrapper>
      </Card>

      {/* ── Create / Edit Slide-Over ── */}
      <SlideOver
        open={slideOpen}
        onClose={() => { setSlideOpen(false); setCreatedPartner(null); }}
        title={createdPartner ? "Partner Site Created!" : editing ? `Edit: /p/${editing.slug}` : "New Partner Site"}
        subtitle={createdPartner ? "The site is live. Share the URL with the partner." : editing ? "Changes take effect immediately." : "Partner sites go live at /p/[slug] with no redeploy needed."}
        width="w-full max-w-2xl"
      >
        {/* ── Post-creation success panel ── */}
        {createdPartner && (
          <div className="space-y-5 pb-6">
            <div className="flex items-center gap-3 p-4 bg-emerald-950/40 border border-emerald-800/40 rounded-2xl">
              <CheckCircle className="w-6 h-6 text-emerald-400 flex-shrink-0" />
              <div>
                <p className="text-sm font-bold text-emerald-300">Partner site is live</p>
                <p className="text-[11px] text-emerald-500 mt-0.5">Slug: <span className="font-mono">{createdPartner.slug}</span> · Status: {createdPartner.status}</p>
              </div>
            </div>

            <SectionHeader>Live URL (default)</SectionHeader>
            <div className="flex items-center gap-2 bg-stone-900 border border-stone-800 rounded-xl px-3 py-2.5">
              <code className="flex-1 text-[11px] text-stone-300 font-mono break-all">
                {window.location.origin}/p/{createdPartner.slug}
              </code>
              <button
                type="button"
                onClick={() => { navigator.clipboard.writeText(`${window.location.origin}/p/${createdPartner.slug}`); setCopiedSlug(createdPartner.slug); setTimeout(() => setCopiedSlug(""), 2000); }}
                className="flex-shrink-0 flex items-center gap-1.5 px-2.5 py-1.5 bg-stone-800 hover:bg-stone-700 text-stone-300 text-[10px] font-semibold rounded-lg transition-colors"
              >
                {copiedSlug === createdPartner.slug ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                {copiedSlug === createdPartner.slug ? "Copied!" : "Copy"}
              </button>
              <a href={`/p/${createdPartner.slug}`} target="_blank" rel="noreferrer" className="flex-shrink-0 p-1.5 rounded-lg hover:bg-stone-800 text-stone-500 hover:text-stone-300 transition-colors">
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            {createdPartner.custom_domain && (
              <>
                <SectionHeader>Custom Domain</SectionHeader>
                <div className="flex items-center gap-2 p-3 bg-amber-950/20 border border-amber-800/30 rounded-xl text-[11px] text-amber-300">
                  <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                  <span><span className="font-mono font-bold">{createdPartner.custom_domain}</span> — not yet attached to Vercel. Open the partner's Edit panel to configure DNS.</span>
                </div>
              </>
            )}

            <div className="flex gap-3 pt-2">
              <Btn variant="primary" onClick={() => { openEdit(createdPartner); }} className="flex-1">Edit This Partner</Btn>
              <Btn variant="secondary" onClick={() => { setSlideOpen(false); setCreatedPartner(null); }}>Done</Btn>
            </div>
          </div>
        )}

        {/* ── Create / Edit form (hidden after creation success) ── */}
        {!createdPartner && <form onSubmit={handleSave} className="space-y-5 pb-6">

          {/* Contact info */}
          <SectionHeader>Contact Information</SectionHeader>
          <div className="grid grid-cols-2 gap-3">
            <FormRow label="Contact name">
              <Input value={form.pendingContactName} onChange={v => setForm(f => ({ ...f, pendingContactName: v }))} placeholder="Jane Doe" />
            </FormRow>
            <FormRow label="Contact phone">
              <Input value={form.pendingContactPhone} onChange={v => setForm(f => ({ ...f, pendingContactPhone: v }))} placeholder="+237 6XXXXXXXX" />
            </FormRow>
          </div>

          {/* Slug */}
          <SectionHeader>Site Identity</SectionHeader>
          <FormRow label={editing ? "Slug" : "Slug *"}>
            <div className="flex items-center gap-2">
              <span className="text-stone-500 text-xs flex-shrink-0">/p/</span>
              <Input
                value={form.slug}
                onChange={v => {
                  const clean = v.toLowerCase().replace(/[^a-z0-9-]/g, "");
                  setForm(f => ({ ...f, slug: clean }));
                  if (editing && clean !== editing.slug) setShowSlugWarning(true);
                  else setShowSlugWarning(false);
                }}
                placeholder="jane-doe"
                mono
              />
            </div>
            {!editing && (
              <p className="text-[10px] text-stone-600 mt-1">Lowercase, letters/numbers/hyphens only.</p>
            )}
            {editing && showSlugWarning && form.slug !== editing.slug && (
              <div className="flex items-start gap-2 mt-2 p-2.5 bg-amber-950/30 border border-amber-800/40 rounded-xl text-[10px] text-amber-300">
                <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
                <span>
                  <strong>Warning:</strong> Changing the slug means the old URL{" "}
                  <code className="font-mono bg-stone-900 px-0.5 rounded">/p/{editing.slug}</code> will stop working.
                  Anyone using that link will see "site not found". Make sure to share the new URL with the partner.
                </span>
              </div>
            )}
          </FormRow>

          {!editing && (
            <FormRow label="Deployment">
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setForm(f => ({ ...f, deploymentMode: "shared_path" }))}
                  className={`text-left p-3 rounded-xl border text-xs transition-colors ${
                    form.deploymentMode === "shared_path"
                      ? "border-emerald-600 bg-emerald-950/30"
                      : "border-stone-800 hover:border-stone-700"
                  }`}
                >
                  <p className="font-semibold text-white">Shared Path</p>
                  <p className="text-stone-500 mt-0.5">Live immediately at <code className="font-mono">/p/{form.slug || "slug"}</code> on this deployment.</p>
                </button>
                <button
                  type="button"
                  onClick={() => setForm(f => ({ ...f, deploymentMode: "standalone" }))}
                  className={`text-left p-3 rounded-xl border text-xs transition-colors ${
                    form.deploymentMode === "standalone"
                      ? "border-violet-600 bg-violet-950/30"
                      : "border-stone-800 hover:border-stone-700"
                  }`}
                >
                  <p className="font-semibold text-white">Standalone</p>
                  <p className="text-stone-500 mt-0.5">Created as "pending" — the partner completes their own setup wizard on their own separate deployment.</p>
                </button>
              </div>
              {form.deploymentMode === "standalone" && (
                <div className="flex items-start gap-2 mt-2 p-2.5 bg-violet-950/20 border border-violet-800/30 rounded-xl text-[10px] text-violet-300">
                  <Globe className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
                  <span>
                    After creating this, deploy a new Vercel/Netlify project from this codebase with
                    {" "}<code className="font-mono bg-stone-900 px-0.5 rounded">PARTNER_SLUG</code> /{" "}
                    <code className="font-mono bg-stone-900 px-0.5 rounded">VITE_PARTNER_SLUG</code> set to
                    {" "}<code className="font-mono bg-stone-900 px-0.5 rounded">{form.slug || "this-slug"}</code>, and the
                    same Supabase credentials as this site. See <code className="font-mono bg-stone-900 px-0.5 rounded">docs/standalone-partner-deployment.md</code>.
                  </span>
                </div>
              )}
            </FormRow>
          )}

          <div className="grid grid-cols-2 gap-3">
            <FormRow label="WhatsApp number">
              <Input value={form.whatsappNumber} onChange={v => setForm(f => ({ ...f, whatsappNumber: v }))} placeholder="+237 6XXXXXXXX" />
            </FormRow>
            <FormRow label="Contact email">
              <Input value={form.contactEmail} onChange={v => setForm(f => ({ ...f, contactEmail: v }))} placeholder="jane@example.com" />
            </FormRow>
          </div>

          <FormRow label="Distributor ID (optional — link to a real distributor account)">
            <Input value={form.distributorId} onChange={v => setForm(f => ({ ...f, distributorId: v }))} placeholder="UUID or leave blank" mono />
            <p className="text-[10px] text-stone-600 mt-1">Leave blank to create a partner site before a distributor account exists. You can link later.</p>
          </FormRow>

          {/* Hero overrides */}
          <SectionHeader>Hero Overrides (optional)</SectionHeader>
          <p className="text-[11px] text-stone-500">Both EN and FR must be set for a hero override to activate. Leave both blank to show the default hero.</p>

          <div className="grid grid-cols-2 gap-3">
            <FormRow label="Hero title (EN)">
              <Input value={form.heroTitleEn} onChange={v => setForm(f => ({ ...f, heroTitleEn: v }))} placeholder="Jane Doe's Store" />
            </FormRow>
            <FormRow label="Hero title (FR)">
              <Input value={form.heroTitleFr} onChange={v => setForm(f => ({ ...f, heroTitleFr: v }))} placeholder="Boutique de Jane Doe" />
            </FormRow>
            <FormRow label="Hero subtitle (EN)">
              <Input value={form.heroSubtitleEn} onChange={v => setForm(f => ({ ...f, heroSubtitleEn: v }))} placeholder="Premium health products" />
            </FormRow>
            <FormRow label="Hero subtitle (FR)">
              <Input value={form.heroSubtitleFr} onChange={v => setForm(f => ({ ...f, heroSubtitleFr: v }))} placeholder="Produits de santé premium" />
            </FormRow>
          </div>
          <FormRow label="Display name (shown publicly on their site)">
            <Input value={form.displayName} onChange={v => setForm(f => ({ ...f, displayName: v }))} placeholder="Jane Doe" />
          </FormRow>

          <FormRow label="Hero / distributor photo">
            <MediaUploader
              bucket="media"
              folder="partners"
              currentUrl={form.heroImageUrl || undefined}
              onUploaded={(url) => setForm(f => ({ ...f, heroImageUrl: url }))}
              onRemoved={() => setForm(f => ({ ...f, heroImageUrl: "" }))}
              accept="image/*"
              label="Drop the partner's photo here or click to browse"
            />
            {/* Advanced fallback — link an already-hosted image instead of uploading */}
            <details className="mt-2">
              <summary className="text-[11px] text-stone-500 cursor-pointer select-none">Use an image URL instead</summary>
              <div className="mt-1.5">
                <Input value={form.heroImageUrl} onChange={v => setForm(f => ({ ...f, heroImageUrl: v }))} placeholder="https://..." />
              </div>
            </details>
          </FormRow>

          {/* Custom domain — edit only. On create, the site is immediately live at /p/:slug.
              Custom domain is a distinct opt-in step added after creation. */}
          {editing && (
            <>
              <SectionHeader>Custom Domain (optional)</SectionHeader>
              <div className="flex items-start gap-2 p-2.5 bg-stone-900/60 border border-stone-800 rounded-xl text-[10px] text-stone-400 mb-1">
                <Globe className="w-3.5 h-3.5 flex-shrink-0 mt-0.5 text-stone-500" />
                <span>
                  The partner site is always live at its{" "}
                  <code className="font-mono bg-stone-900 px-0.5 rounded">/p/{editing.slug}</code>{" "}
                  URL. A custom domain is an opt-in addition — the slug URL keeps working alongside it.
                </span>
              </div>
              <FormRow label="Custom domain">
                <Input
                  value={form.customDomain}
                  onChange={v => setForm(f => ({ ...f, customDomain: v.trim().toLowerCase() }))}
                  placeholder="janedoe-wellness.com"
                />
                {form.customDomain && editing.custom_domain &&
                  form.customDomain !== editing.custom_domain &&
                  (editing.domain_status === "verified" || editing.domain_status === "pending_verification") && (
                  <div className="flex items-start gap-2 mt-2 p-2.5 bg-red-950/30 border border-red-800/40 rounded-xl text-[10px] text-red-300">
                    <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
                    <span>
                      <strong>Warning:</strong> Your current domain{" "}
                      <code className="font-mono bg-stone-900 px-0.5 rounded">{editing.custom_domain}</code>{" "}
                      will stop working once you save this change. Make sure the new domain is ready before saving.
                    </span>
                  </div>
                )}
              </FormRow>
            </>
          )}

          {/* Domain verification — shown when editing and a domain is saved or typed */}
          {editing && (editing.custom_domain || form.customDomain) && (
            <div className="space-y-3">
              <SectionHeader>Domain Verification</SectionHeader>

              {/* Status badge — based on saved editing state */}
              {editing.custom_domain && (
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-[10px] text-stone-500 font-mono">{editing.custom_domain}</span>
                  {editing.domain_status === "verified" && (
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-900/40 text-emerald-400 border border-emerald-800/40">
                      <Shield className="w-3 h-3" /> Verified — SSL active
                    </span>
                  )}
                  {editing.domain_status === "pending_verification" && (
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-900/40 text-amber-400 border border-amber-800/40">
                      <AlertTriangle className="w-3 h-3" /> Pending DNS verification
                    </span>
                  )}
                  {(editing.domain_status === "none" || !editing.domain_status) && (
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-stone-800 text-stone-400 border border-stone-700">
                      Not yet attached to Vercel
                    </span>
                  )}
                  {editing.domain_status === "failed" && (
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-red-900/30 text-red-400 border border-red-800/30">
                      <XCircle className="w-3 h-3" /> Verification failed — check DNS record
                    </span>
                  )}
                </div>
              )}

              {/* Hint when domain field has a new unsaved value */}
              {form.customDomain && form.customDomain !== editing.custom_domain && (
                <p className="text-[10px] text-amber-400 bg-amber-950/20 border border-amber-800/30 rounded-xl px-3 py-2">
                  Save changes first, then use "Attach domain" to register{" "}
                  <span className="font-mono font-bold">{form.customDomain}</span> with the hosting provider and get DNS records.
                </p>
              )}

              {/* Attach button — only if saved domain matches form and not yet added to Vercel */}
              {editing.custom_domain &&
                form.customDomain === editing.custom_domain &&
                (editing.domain_status === "none" || !editing.domain_status) && (
                <div className="flex items-center gap-2">
                  <Btn
                    variant="secondary" size="xs"
                    loading={domainOp === "attaching"}
                    onClick={() => attachDomain(editing.id, editing.custom_domain!)}
                  >
                    <Globe className="w-3 h-3" />
                    Attach domain
                  </Btn>
                  <p className="text-[10px] text-stone-500">Registers the domain with the hosting provider and returns real DNS records to set at your registrar.</p>
                </div>
              )}

              {/* Check status button — if pending or failed */}
              {editing.custom_domain &&
                form.customDomain === editing.custom_domain &&
                (editing.domain_status === "pending_verification" || editing.domain_status === "failed") && (
                <div className="flex items-center gap-2">
                  <Btn
                    variant="secondary" size="xs"
                    loading={domainOp === "checking"}
                    onClick={() => checkDomainStatus(editing.id)}
                  >
                    <RefreshCw className="w-3 h-3" />
                    Check now
                  </Btn>
                  <p className="text-[10px] text-stone-500">
                    Background checks run automatically every ~20 min. Use this to check immediately.
                  </p>
                </div>
              )}

              {/* Remove domain button — always available if a domain is saved */}
              {editing.custom_domain && (
                <div className="flex items-center gap-2">
                  <Btn
                    variant="danger" size="xs"
                    loading={domainOp === "removing"}
                    onClick={() => {
                      if (window.confirm(`Remove "${editing.custom_domain}" and revert to slug-only URL?`)) {
                        removeDomain(editing.id);
                      }
                    }}
                  >
                    <XCircle className="w-3 h-3" />
                    Remove domain
                  </Btn>
                  <p className="text-[10px] text-stone-500">
                    Detaches from Vercel. The site stays live at its slug URL.
                  </p>
                </div>
              )}

              {/* Operation message */}
              {domainOpMsg && (
                <p className={`text-[11px] leading-relaxed ${
                  editing.domain_status === "verified" ? "text-emerald-400" :
                  domainOp === null && domainOpMsg.includes("removed") ? "text-stone-400" :
                  "text-stone-400"
                }`}>
                  {domainOpMsg}
                </p>
              )}

              {/* DNS records table */}
              {dnsRecords.length > 0 && (
                <div className="space-y-2">
                  <p className="text-[11px] font-semibold text-stone-400 uppercase tracking-wide">DNS Records — add these at your registrar</p>
                  <div className="rounded-xl border border-stone-800 overflow-hidden">
                    <table className="w-full text-[10px]">
                      <thead className="bg-stone-800/60">
                        <tr>
                          <th className="text-left px-3 py-1.5 text-stone-400 font-semibold">Type</th>
                          <th className="text-left px-3 py-1.5 text-stone-400 font-semibold">Name / Host</th>
                          <th className="text-left px-3 py-1.5 text-stone-400 font-semibold">Value</th>
                          <th className="px-3 py-1.5" />
                        </tr>
                      </thead>
                      <tbody>
                        {dnsRecords.map((r, i) => (
                          <tr key={i} className="border-t border-stone-800">
                            <td className="px-3 py-1.5 font-mono text-amber-400 font-bold">{r.type}</td>
                            <td className="px-3 py-1.5 font-mono text-stone-300">{r.domain}</td>
                            <td className="px-3 py-1.5 font-mono text-stone-400 break-all">{r.value}</td>
                            <td className="px-3 py-1.5">
                              <button
                                type="button"
                                onClick={() => navigator.clipboard.writeText(r.value)}
                                className="p-1 rounded hover:bg-stone-700 text-stone-500 hover:text-stone-300 transition-colors"
                                title="Copy value"
                              >
                                <Copy className="w-2.5 h-2.5" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <p className="text-[10px] text-stone-500">
                    <strong className="text-stone-400">DNS propagation takes time</strong> — from a few minutes to 24–48 hours depending on your registrar and TTL settings. This is completely normal.
                    Your slug URL keeps working throughout. Background checks run every ~20 min; use "Check now" to verify immediately.
                  </p>
                </div>
              )}

              {/* Verified state — no action needed */}
              {editing.domain_status === "verified" && dnsRecords.length === 0 && form.customDomain === editing.custom_domain && (
                <p className="text-[11px] text-stone-500">
                  Domain is verified and serving traffic. SSL is active. The site also remains accessible at its slug URL{" "}
                  <code className="font-mono bg-stone-900 px-0.5 rounded">/p/{editing.slug}</code>.
                </p>
              )}
            </div>
          )}

          {/* Status */}
          <SectionHeader>Visibility</SectionHeader>
          <FormRow label={editing ? "Status" : "Initial status"}>
            <div className="flex gap-3 flex-wrap">
              {(editing
                ? (["active", "pending", "suspended"] as const)
                : (["active", "pending"] as const)
              ).map(s => (
                <label key={s} className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="status"
                    value={s}
                    checked={form.status === s}
                    onChange={() => setForm(f => ({ ...f, status: s }))}
                    className="accent-emerald-600"
                  />
                  <span className="text-xs text-stone-300 capitalize">{s}</span>
                </label>
              ))}
            </div>
            {!editing && (
              <p className="text-[10px] text-stone-600 mt-1">Admin-created sites can go live immediately ("active") — you are the approver.</p>
            )}
          </FormRow>

          {error && (
            <div className="flex items-start gap-2 p-3 bg-red-950/30 border border-red-800/40 rounded-xl text-xs text-red-300">
              <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" />
              {error}
            </div>
          )}

          {savedMsg && (
            <div className="flex items-center gap-2 p-3 bg-emerald-950/30 border border-emerald-800/40 rounded-xl text-xs text-emerald-300">
              <CheckCircle className="w-4 h-4 flex-shrink-0" />
              {savedMsg}
            </div>
          )}

          <div className="flex gap-3 pt-2">
            <Btn variant="primary" loading={saving} className="flex-1" onClick={() => {}}>
              {editing ? "Save Changes" : "Create Partner Site"}
            </Btn>
            <Btn variant="secondary" onClick={() => { setSlideOpen(false); setShowSlugWarning(false); }}>
              {editing ? "Close" : "Cancel"}
            </Btn>
          </div>
        </form>}
      </SlideOver>
    </PageShell>
  );
}
