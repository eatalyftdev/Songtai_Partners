import { useState, ChangeEvent, FormEvent } from "react";
import { motion } from "motion/react";
import { Upload, X, Loader2, Rocket, CheckCircle2 } from "lucide-react";
import type { PartnerData } from "../../context/PartnerContext";

interface PartnerSetupProps {
  /** Pre-filled values when an admin already pre-created this partner as "pending". */
  prefill: Partial<PartnerData> | null;
}

/**
 * First-run setup wizard for a STANDALONE partner deployment — this whole
 * screen only ever renders on a fresh deployment that hasn't been configured
 * yet (see PartnerContext's "needs_setup" state). Once submitted, the
 * partner's own row is created/completed in the shared Supabase database and
 * the app reloads straight into the live site.
 */
export default function PartnerSetup({ prefill }: PartnerSetupProps) {
  const [displayName, setDisplayName] = useState(prefill?.display_name ?? prefill?.pending_contact_name ?? "");
  const [whatsappNumber, setWhatsappNumber] = useState(prefill?.whatsapp_number ?? prefill?.pending_contact_phone ?? "");
  const [contactEmail, setContactEmail] = useState(prefill?.contact_email ?? "");
  const [heroTitleEn, setHeroTitleEn] = useState(prefill?.hero_title_en ?? "");
  const [heroTitleFr, setHeroTitleFr] = useState(prefill?.hero_title_fr ?? "");
  const [heroSubtitleEn, setHeroSubtitleEn] = useState(prefill?.hero_subtitle_en ?? "");
  const [heroSubtitleFr, setHeroSubtitleFr] = useState(prefill?.hero_subtitle_fr ?? "");
  const [heroImageUrl, setHeroImageUrl] = useState(prefill?.hero_image_url ?? "");
  const [photoPreview, setPhotoPreview] = useState<string | null>(prefill?.hero_image_url ?? null);

  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);

  const handlePhotoChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      setError("Photo is too large — please choose an image under 5MB.");
      return;
    }

    const reader = new FileReader();
    reader.onload = async () => {
      const dataUrl = reader.result as string;
      setPhotoPreview(dataUrl);
      setUploading(true);
      setError("");
      try {
        const res = await fetch("/api/partner-setup/upload-photo", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ imageBase64: dataUrl, mimeType: file.type }),
        });
        const json = await res.json();
        if (!res.ok) throw new Error(json.error || "Upload failed.");
        setHeroImageUrl(json.url);
      } catch (err: any) {
        setError(err.message || "Photo upload failed. You can still finish setup and add a photo later.");
        setPhotoPreview(null);
      } finally {
        setUploading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const removePhoto = () => {
    setPhotoPreview(null);
    setHeroImageUrl("");
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError("");

    if (!whatsappNumber.trim()) {
      setError("A WhatsApp number is required so customers can reach you.");
      return;
    }
    if (uploading) {
      setError("Please wait for the photo to finish uploading.");
      return;
    }

    setSaving(true);
    try {
      const res = await fetch("/api/partner-setup/complete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          displayName: displayName.trim() || null,
          whatsappNumber: whatsappNumber.trim(),
          contactEmail: contactEmail.trim() || null,
          heroTitleEn: heroTitleEn.trim() || null,
          heroTitleFr: heroTitleFr.trim() || null,
          heroSubtitleEn: heroSubtitleEn.trim() || null,
          heroSubtitleFr: heroSubtitleFr.trim() || null,
          heroImageUrl: heroImageUrl || null,
        }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Setup failed.");

      setDone(true);
      // Reload straight into the live site — PartnerContext re-resolves fresh.
      setTimeout(() => window.location.reload(), 1200);
    } catch (err: any) {
      setError(err.message || "Something went wrong. Please try again.");
      setSaving(false);
    }
  };

  if (done) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "var(--color-bg)" }}>
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex flex-col items-center gap-3 text-center px-6"
        >
          <CheckCircle2 className="w-12 h-12" style={{ color: "var(--color-primary)" }} />
          <h1 className="text-xl font-bold" style={{ color: "var(--color-fg)" }}>You're live!</h1>
          <p className="text-sm" style={{ color: "var(--color-muted)" }}>Loading your new site…</p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-16" style={{ background: "var(--color-bg)" }}>
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-xl rounded-3xl border p-6 sm:p-10 space-y-6"
        style={{ background: "var(--color-surface)", borderColor: "var(--color-border)" }}
      >
        <div className="space-y-1.5 text-center">
          <span className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide" style={{ color: "var(--color-primary)" }}>
            <Rocket className="w-3.5 h-3.5" /> Welcome — let's set up your site
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold" style={{ color: "var(--color-fg)", fontFamily: "var(--font-display)" }}>
            A few details, then you're live
          </h1>
          <p className="text-sm max-w-md mx-auto" style={{ color: "var(--color-muted)" }}>
            This information appears on your own Songtai Life partner site. You can change all of it later — just ask your admin.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Photo — optional */}
          <div className="flex flex-col items-center gap-3">
            <div
              className="relative w-28 h-28 rounded-2xl overflow-hidden flex items-center justify-center border-2 border-dashed"
              style={{ borderColor: "var(--color-border)", background: "var(--color-bg)" }}
            >
              {photoPreview ? (
                <>
                  <img src={photoPreview} alt="Your photo" className="w-full h-full object-cover" />
                  {uploading && (
                    <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                      <Loader2 className="w-5 h-5 animate-spin text-white" />
                    </div>
                  )}
                  <button
                    type="button"
                    onClick={removePhoto}
                    className="absolute top-1 right-1 w-6 h-6 rounded-full bg-black/70 flex items-center justify-center"
                    aria-label="Remove photo"
                  >
                    <X className="w-3.5 h-3.5 text-white" />
                  </button>
                </>
              ) : (
                <label className="flex flex-col items-center gap-1 cursor-pointer text-center px-2">
                  <Upload className="w-5 h-5" style={{ color: "var(--color-muted)" }} />
                  <span className="text-[10px]" style={{ color: "var(--color-muted)" }}>Add photo (optional)</span>
                  <input type="file" accept="image/*" className="hidden" onChange={handlePhotoChange} />
                </label>
              )}
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold mb-1 block" style={{ color: "var(--color-fg)" }}>Your name</label>
            <input
              value={displayName}
              onChange={e => setDisplayName(e.target.value)}
              placeholder="e.g. Amina N."
              className="w-full px-3.5 py-2.5 rounded-xl border text-sm"
              style={{ borderColor: "var(--color-border)", background: "var(--color-bg)", color: "var(--color-fg)" }}
            />
          </div>

          <div>
            <label className="text-xs font-semibold mb-1 block" style={{ color: "var(--color-fg)" }}>
              WhatsApp number <span style={{ color: "var(--color-accent)" }}>*</span>
            </label>
            <input
              value={whatsappNumber}
              onChange={e => setWhatsappNumber(e.target.value)}
              placeholder="e.g. 237600000000"
              required
              className="w-full px-3.5 py-2.5 rounded-xl border text-sm"
              style={{ borderColor: "var(--color-border)", background: "var(--color-bg)", color: "var(--color-fg)" }}
            />
          </div>

          <div>
            <label className="text-xs font-semibold mb-1 block" style={{ color: "var(--color-fg)" }}>Email (optional)</label>
            <input
              type="email"
              value={contactEmail}
              onChange={e => setContactEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full px-3.5 py-2.5 rounded-xl border text-sm"
              style={{ borderColor: "var(--color-border)", background: "var(--color-bg)", color: "var(--color-fg)" }}
            />
          </div>

          <details className="group">
            <summary className="text-xs font-semibold cursor-pointer select-none" style={{ color: "var(--color-primary)" }}>
              Customize your homepage headline (optional)
            </summary>
            <div className="mt-3 space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  value={heroTitleEn} onChange={e => setHeroTitleEn(e.target.value)}
                  placeholder="Headline (English)"
                  className="px-3.5 py-2.5 rounded-xl border text-sm"
                  style={{ borderColor: "var(--color-border)", background: "var(--color-bg)", color: "var(--color-fg)" }}
                />
                <input
                  value={heroTitleFr} onChange={e => setHeroTitleFr(e.target.value)}
                  placeholder="Titre (Français)"
                  className="px-3.5 py-2.5 rounded-xl border text-sm"
                  style={{ borderColor: "var(--color-border)", background: "var(--color-bg)", color: "var(--color-fg)" }}
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  value={heroSubtitleEn} onChange={e => setHeroSubtitleEn(e.target.value)}
                  placeholder="Subtitle (English)"
                  className="px-3.5 py-2.5 rounded-xl border text-sm"
                  style={{ borderColor: "var(--color-border)", background: "var(--color-bg)", color: "var(--color-fg)" }}
                />
                <input
                  value={heroSubtitleFr} onChange={e => setHeroSubtitleFr(e.target.value)}
                  placeholder="Sous-titre (Français)"
                  className="px-3.5 py-2.5 rounded-xl border text-sm"
                  style={{ borderColor: "var(--color-border)", background: "var(--color-bg)", color: "var(--color-fg)" }}
                />
              </div>
            </div>
          </details>

          {error && (
            <p className="text-xs font-medium px-3 py-2 rounded-lg" style={{ color: "var(--color-accent)", background: "rgba(231,56,13,0.08)" }}>
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={saving || uploading}
            className="w-full py-3.5 rounded-full font-bold text-sm flex items-center justify-center gap-2 disabled:opacity-60"
            style={{ background: "var(--color-primary)", color: "var(--color-primary-fg)" }}
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Rocket className="w-4 h-4" />}
            {saving ? "Going live…" : "Complete Setup & Go Live"}
          </button>
        </form>
      </motion.div>
    </div>
  );
}
