import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { ExternalLink, Building2, Loader2 } from "lucide-react";
import { useTranslation } from "react-i18next";

// Present only on a standalone partner deployment (its own separate project).
// On the shared deployment this is undefined, so this.origin genuinely IS the
// main company site — the original same-origin behavior stays correct there.
const STANDALONE_SLUG: string | null = (import.meta as any).env?.VITE_PARTNER_SLUG || null;
const MAIN_SITE_URL: string = ((import.meta as any).env?.VITE_MAIN_SITE_URL || "https://songtailife.cm").replace(/\/$/, "");

/**
 * "View Company" page — partner sites only.
 *
 * This is intentionally a near-empty shell: its only job is to embed the main
 * Songtai Life Cameroon website inline so a partner's visitors can browse the
 * official company site without leaving the partner's own site chrome
 * (nav/footer stay, per BrandShowcase's layout).
 *
 * On the SHARED deployment (/p/:slug), the main site is this same app's own
 * origin ("/") — one single-page app serving both. On a STANDALONE partner
 * deployment (its own separate Vercel/Netlify project), "/" is this same
 * partner's own site, not the company's — so standalone deployments instead
 * point at VITE_MAIN_SITE_URL, the real main company site's URL.
 */
export default function CompanyView() {
  const { t } = useTranslation();
  const [loaded, setLoaded] = useState(false);
  const [timedOut, setTimedOut] = useState(false);

  const companyUrl = STANDALONE_SLUG
    ? `${MAIN_SITE_URL}/`
    : (typeof window !== "undefined" ? `${window.location.origin}/` : "/");

  // A blocked embed (e.g. cross-origin CSP frame-ancestors restrictions on a
  // standalone partner deployment) doesn't reliably fire an iframe onError —
  // browsers just show a blank frame forever. A load timeout is the only
  // reliable way to detect this and offer a graceful "open in new tab"
  // fallback instead of leaving visitors staring at an empty box.
  useEffect(() => {
    if (loaded) return;
    const timer = setTimeout(() => setTimedOut(true), 6000);
    return () => clearTimeout(timer);
  }, [loaded, companyUrl]);

  return (
    <div className="min-h-screen flex flex-col" style={{ background: "var(--color-bg)" }}>
      {/* Minimal header — this page is deliberately empty chrome around the embed */}
      <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 pt-24 sm:pt-28 pb-6">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4"
        >
          <div className="flex items-center gap-3">
            <div
              className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{ background: "var(--color-surface)", border: "1px solid var(--color-border)" }}
            >
              <Building2 className="w-5 h-5" style={{ color: "var(--color-primary)" }} />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold" style={{ color: "var(--color-fg)", fontFamily: "var(--font-display)" }}>
                {t("company.title")}
              </h1>
              <p className="text-sm" style={{ color: "var(--color-muted)" }}>
                {t("company.viewing")}
              </p>
            </div>
          </div>

          <a
            href={companyUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold border transition-colors flex-shrink-0 self-start sm:self-auto"
            style={{ borderColor: "var(--color-border)", color: "var(--color-fg)" }}
          >
            {t("company.openNewTab")}
            <ExternalLink className="w-4 h-4" />
          </a>
        </motion.div>
      </div>

      {/* The embed itself */}
      <div className="flex-grow max-w-7xl mx-auto w-full px-4 sm:px-6 pb-16">
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
          className="relative w-full rounded-2xl overflow-hidden border shadow-xl"
          style={{ borderColor: "var(--color-border)", height: "min(80vh, 900px)" }}
        >
          {!loaded && !timedOut && (
            <div
              className="absolute inset-0 flex flex-col items-center justify-center gap-3 z-10"
              style={{ background: "var(--color-surface)" }}
            >
              <Loader2 className="w-6 h-6 animate-spin" style={{ color: "var(--color-primary)" }} />
              <span className="text-sm" style={{ color: "var(--color-muted)" }}>{t("company.loading")}</span>
            </div>
          )}
          {timedOut && !loaded ? (
            // Couldn't confirm the embed loaded (most likely a cross-origin
            // frame-ancestors restriction on a standalone deployment) —
            // don't leave visitors staring at a blank box, offer the direct link.
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 px-6 text-center">
              <Building2 className="w-8 h-8" style={{ color: "var(--color-muted)" }} />
              <p className="text-sm max-w-xs" style={{ color: "var(--color-muted)" }}>
                {t("company.viewing")}
              </p>
              <a
                href={companyUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold"
                style={{ background: "var(--color-primary)", color: "var(--color-primary-fg)" }}
              >
                {t("company.openNewTab")}
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          ) : (
            <iframe
              src={companyUrl}
              title="Songtai Life Cameroon"
              className="w-full h-full"
              style={{ border: "none" }}
              loading="lazy"
              onLoad={() => setLoaded(true)}
            />
          )}
        </motion.div>
      </div>
    </div>
  );
}
