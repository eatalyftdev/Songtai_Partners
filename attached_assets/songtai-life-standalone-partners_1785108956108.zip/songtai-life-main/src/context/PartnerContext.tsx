import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useLocation } from "react-router-dom";
import { supabase } from "../lib/supabase";

// ── Partner shape (mirrors the `partners` table) ────────────────────────────
export interface PartnerData {
  id: string;
  slug: string;
  distributor_id: string | null;
  display_name: string | null;
  whatsapp_number: string | null;
  contact_email: string | null;
  hero_title_en: string | null;
  hero_title_fr: string | null;
  hero_subtitle_en: string | null;
  hero_subtitle_fr: string | null;
  hero_image_url: string | null;
  status: string;
  // Present only when a standalone deployment fetches a "pending" row that an
  // admin pre-created — used to pre-fill the self-service setup wizard.
  pending_contact_name?: string | null;
  pending_contact_phone?: string | null;
}

export const PartnerContext = createContext<PartnerData | null>(null);

/** Read the current partner (null on the main site). */
export function usePartner(): PartnerData | null {
  return useContext(PartnerContext);
}

// Set on a STANDALONE partner deployment only (its own separate Vercel/Netlify
// project) — tells the client "this whole app IS one specific partner's site",
// as opposed to the shared deployment's /p/:slug path-based resolution.
// Never set on the main site or on the shared deployment.
const STANDALONE_SLUG: string | null = (import.meta as any).env?.VITE_PARTNER_SLUG || null;

// ── State machine for the loader ─────────────────────────────────────────────
type LoadState = "idle" | "loading" | "active" | "not_found" | "needs_setup";

interface PartnerProviderProps {
  children: ReactNode;
  /** Rendered when the slug exists but partner is inactive/not found. */
  notAvailableSlot: (slug: string) => ReactNode;
  /** Rendered while fetching partner data. */
  loadingSlot: ReactNode;
  /**
   * Rendered on a standalone deployment that hasn't completed setup yet.
   * Receives a partial partner row when an admin pre-created a "pending"
   * placeholder (for pre-filling the form), or null for a fully blank setup.
   * Only ever invoked when STANDALONE_SLUG is set — the shared /p/:slug mode
   * never reaches "needs_setup" (a missing shared-path partner is just
   * "not_found", since there's no separate deployment to "set up").
   */
  setupSlot?: (prefill: Partial<PartnerData> | null) => ReactNode;
}

/**
 * Must be placed inside <BrowserRouter>.
 *
 * Two resolution modes, mutually exclusive per deployment:
 *
 * 1. Shared path mode (STANDALONE_SLUG unset — the normal shared deployment):
 *    when the URL matches /p/:slug, fetches that partner row directly via the
 *    anon-key Supabase client (existing behavior, unchanged).
 *
 * 2. Standalone mode (STANDALONE_SLUG set — this deployment IS one partner's
 *    own site): resolves via the server's /api/partner-setup/status endpoint
 *    instead, since that route uses the service-role key and can see
 *    "pending" rows the anon-key client's RLS wouldn't return. This is what
 *    powers the first-run setup wizard.
 */
export function PartnerProvider({ children, notAvailableSlot, loadingSlot, setupSlot }: PartnerProviderProps) {
  const location = useLocation();
  const [state, setState] = useState<LoadState>("idle");
  const [partner, setPartner] = useState<PartnerData | null>(null);
  const [setupPrefill, setSetupPrefill] = useState<Partial<PartnerData> | null>(null);
  const [currentSlug, setCurrentSlug] = useState<string | null>(null);

  // Extract slug from /p/:slug (any deeper path is fine: /p/johndoe/products etc.)
  const pathSlugMatch = location.pathname.match(/^\/p\/([^/]+)/);
  const pathSlug = pathSlugMatch?.[1] ?? null;

  const slug = STANDALONE_SLUG || pathSlug;

  useEffect(() => {
    if (STANDALONE_SLUG) {
      // ── Standalone deployment: resolve via the server, once per app load ──
      if (currentSlug === STANDALONE_SLUG) return;
      setState("loading");
      setCurrentSlug(STANDALONE_SLUG);

      fetch("/api/partner-setup/status")
        .then(r => r.json())
        .then(json => {
          if (json.configured && json.partner) {
            setPartner(json.partner as PartnerData);
            setState("active");
          } else if (json.suspended) {
            setPartner(null);
            setState("not_found");
          } else if (json.needsSetup) {
            // json.partner may hold a pending row's already-known fields for pre-fill
            setSetupPrefill(json.partner ?? null);
            setState("needs_setup");
          } else {
            setState("not_found");
          }
        })
        .catch(() => setState("not_found"));
      return;
    }

    // ── Shared deployment: existing /p/:slug behavior, unchanged ──────────
    if (!pathSlug) {
      setState("idle");
      setPartner(null);
      setCurrentSlug(null);
      return;
    }
    if (pathSlug === currentSlug) return;

    setState("loading");
    setCurrentSlug(pathSlug);

    supabase
      .from("partners")
      .select(
        "id, slug, distributor_id, display_name, whatsapp_number, contact_email, " +
        "hero_title_en, hero_title_fr, hero_subtitle_en, hero_subtitle_fr, " +
        "hero_image_url, status"
      )
      .eq("slug", pathSlug)
      .eq("status", "active")
      .single()
      .then(({ data, error }) => {
        const row = data as unknown as PartnerData | null;
        if (error || !row || row.status !== "active") {
          setPartner(null);
          setState("not_found");
        } else {
          setPartner(row);
          setState("active");
        }
      });
  }, [pathSlug, currentSlug]);

  if (slug && state === "loading") return <>{loadingSlot}</>;
  if (slug && state === "not_found") return <>{notAvailableSlot(slug)}</>;
  if (STANDALONE_SLUG && state === "needs_setup" && setupSlot) return <>{setupSlot(setupPrefill)}</>;

  return (
    <PartnerContext.Provider value={partner}>
      {children}
    </PartnerContext.Provider>
  );
}
