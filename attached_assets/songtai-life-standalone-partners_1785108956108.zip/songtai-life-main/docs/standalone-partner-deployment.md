# Deploying a Standalone Partner Site

A standalone partner site is its own separate Vercel or Netlify project, with its own URL,
sharing the same Supabase database as the main Songtai Life site. Use this when a partner
wants their own dedicated domain/hosting rather than the shared `/p/:slug` path.

## Steps

1. **In the main admin panel** (Partners → Create), choose **Standalone** as the deployment
   type and fill in whatever details you already know (name, WhatsApp, etc. are all optional
   at this stage). This creates a `pending` row that the deployment below will complete.

2. **Create a new hosting project** on Vercel or Netlify, from this same repository/branch.

3. **Set these environment variables** on that new project:

   | Variable | Value |
   |---|---|
   | `SUPABASE_URL` | Same as the main site — identical shared database |
   | `SUPABASE_ANON_KEY` | Same as the main site |
   | `SUPABASE_SERVICE_ROLE_KEY` | Same as the main site |
   | `PARTNER_SLUG` | The exact slug chosen in step 1 |
   | `VITE_PARTNER_SLUG` | Same value as `PARTNER_SLUG` |
   | `SITE_URL` | This deployment's own live domain (its default platform URL to start) |
   | `VITE_SITE_URL` | Same value as `SITE_URL` |
   | `VITE_MAIN_SITE_URL` | The actual main company site's URL |

4. **Deploy.** On first visit, the site shows a setup wizard (pre-filled with anything already
   entered in step 1). Completing it activates the partner and the site goes live — no
   redeploy needed.

5. **Verify in the main admin panel** — the partner's row should now show deployment mode
   "Standalone", a populated live URL, and a setup-completed timestamp.

## Notes

- Suspending this partner from the main admin panel does **not** take down their hosting —
  it makes the shared database report them as unavailable, which their deployment correctly
  displays as a "not available" page. Their actual Vercel/Netlify project is untouched.
- A custom domain can be attached to this deployment the same way as any other Vercel/Netlify
  project, independent of the partner-site logic above.
- Whoever has this deployment's environment variables can complete (or re-complete, while the
  row is still `pending`) this partner's setup — treat those env vars with the same care as
  any other production secret.
